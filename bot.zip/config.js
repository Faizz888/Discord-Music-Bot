exports.Token = "NzMwNjk2NDI2MzY3MjIxNzcw.XwbQEw.QJPweaPMbhhL44M0C6i0ZJwyCIY"; //Bot Token - Important
exports.Owner = "64088984786651329"; //Bot Owner ID - Important
exports.Default_Prefix = "-"; //Bot Default Prefix (Examples: A!, !)- Important
exports.Color = "BLUE"; //Bot All Embeds Color - Use CAPS For Name (Examples: BLUE, RANDOM) - Important
exports.Support = `731415338310172684`; //Support Server Link - Never Gonna Give You Up (If No Link Provided)
exports.Donate = `https://www.paypal.com/paypalme/legendemoji`; //Please Don't Change It, If You Want To Support Me <3